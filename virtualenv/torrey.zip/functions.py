#!/usr/bin/Python

from datetime import datetime, timedelta
import requests, json, boto3

teetimesurl = {"South" : "https://foreupsoftware.com/index.php/api/booking/times?api_key=no_limits&booking_class=888&holes=18&schedule_id=1487&",
               "North" : "https://foreupsoftware.com/index.php/api/booking/times?api_key=no_limits&booking_class=888&holes=18&schedule_id=1468&"
            }
loginurl = "https://foreupsoftware.com/index.php/api/booking/users/login"
username = "pecnikdc@gmail.com"
password = "sw14aau"

s3_bucket = "torrey-times"

def my_handler(event, context):

    logincookie = login()
    resultsSouth = getTimes(logincookie,teetimesurl.get("South"))
    for i in resultsSouth:
        print resultsSouth.values()
    resultsNorth = getTimes(logincookie,teetimesurl.get("North"))
    for i in resultsNorth:
        print resultsNorth.values()

    #print results
    #print json.dumps(results)
    if ( len(resultsSouth) !=0):
        pubSNS(resultsSouth,"arn:aws:sns:us-west-2:584679212105:notifications")

    if ( len(resultsNorth) !=0):
        pubSNS(resultsNorth,"arn:aws:sns:us-west-2:584679212105:notifications")

def login():
    
    data = {"username" : username,
            "password" : password,
            "booking_class_id" : "888",
            "api_key" : "no_limits"  
           }

    r = requests.post(loginurl, data=data)

    token =  r.cookies.get("token")
    phpsession = r.cookies.get("PHPSESSID")
    cookie = {"token": token,
              "PHPSESSID" : phpsession
        }

    return cookie

def getTimes(cookie,courseurl):

    times = ["morning","midday","evening"]
    headers = {"Api_key" : "no_limits"}

    #Start at minus one to get current day
    date = datetime.now() + timedelta(days=-1)

    count = 0
    results={}
    #Loops through the next 1days for tee times
    while (count < 8):
        
        teetimesday = courseurl
        date = date + timedelta(days=+1)
        date_formatted = date.strftime("%m-%d-%Y")
        print date_formatted
        count = count + 1
        teetimesday = teetimesday + "date=" + date_formatted

        t = requests.get(teetimesday, cookies=cookie, headers=headers)

        data = json.loads(t.text)
        print data
        if ( len(data) != 0):
            results[date_formatted] = data
            putS3(date_formatted,t.text)
    
    return results

def pubSNS(message,arn):

    client = boto3.client('sns')
    response = client.publish(
        TargetArn=arn,
        Message=json.dumps({'default': json.dumps(message)}),
        MessageStructure='json'
    )

def putS3(key, value):

    s3_client = boto3.client('s3')
    s3_client.put_object(
        Bucket=s3_bucket, 
        Key=key,
        Body=value,
        ContentType='application/json')